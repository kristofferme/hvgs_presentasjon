# Hustadvika VGS — Presentasjon med CMS

## Første gangs oppsett (gjøres én gang, ca. 10 min)

### 1. Opprett GitHub-repo
1. Gå til https://github.com/new
2. Kall repoet f.eks. `hustadvika-presentasjon`
3. Gjør det **privat** (anbefalt)
4. Last opp alle filene fra denne mappen til repoet

### 2. Koble til Netlify
1. Gå til https://app.netlify.com → "Add new site" → "Import an existing project"
2. Velg GitHub og autoriser
3. Velg `hustadvika-presentasjon`-repoet
4. Build settings: la alt stå tomt (ingen build-kommando, publish directory = `.`)
5. Klikk "Deploy site"

### 3. Aktiver Netlify Identity
1. I Netlify-dashboardet: **Site configuration → Identity → Enable Identity**
2. Under "Registration preferences": velg **Invite only**
3. Under "Services → Git Gateway": klikk **Enable Git Gateway**
4. Gå til **Identity-fanen** → "Invite users" → skriv inn din e-post
5. Du får en e-post — klikk lenken og sett passord

### 4. Logg inn i CMS
1. Gå til `https://[ditt-sitenavn].netlify.app/admin/`
2. Logg inn med e-postadressen din
3. **Du er i gang!**

---

## Daglig bruk — slik redigerer du

### Redigere tekst på en slide
1. Gå til `/admin/`
2. Klikk **📑 Slides** i venstremenyen
3. Klikk på sliden du vil endre
4. Endre tekst i feltene
5. Klikk **Publish** (eller **Save draft** for å jobbe videre)
6. Endringen er live innen ~30 sekunder

### Laste opp ny logo
1. Gå til **⚙️ Presentasjonsinnstillinger → Global konfig**
2. Klikk på "Skolelogo"-feltet → last opp SVG eller PNG
3. Klikk **Publish** — logoen oppdateres på alle slides

### Legge til bilde på en slide
1. Åpne sliden i CMS
2. Bytt "Layout" til **📸 Bilde + tekst**
3. Klikk på "Bilde"-feltet og last opp
4. Klikk **Publish**

### Legge til ny slide
1. I **📑 Slides**: klikk **New Slide**
2. Sett "Rekkefølge" (lavere tall = tidligere i presentasjonen)
   - Bruk 10, 20, 30 etc. så du kan sette inn mellom eksisterende slides
3. Velg layout og tema
4. Fyll inn innhold
5. Klikk **Publish**

### Endre rekkefølge på slides
- Endre "Rekkefølge"-nummeret på de aktuelle slidene
- Presentasjonen sorterer automatisk etter dette nummeret

### Slette en slide
- Åpne sliden → klikk de tre prikkene (⋯) øverst → **Delete**

---

## Mappestruktur

```
hustadvika-presentasjon/
├── index.html              ← selve presentasjonen
├── admin/
│   ├── index.html          ← CMS-grensesnitt
│   └── config.yml          ← CMS-konfigurasjon
├── _data/
│   ├── settings.json       ← logo, farger, skolenavn
│   ├── slides-index.json   ← liste over slide-filer (oppdater ved nye slides)
│   └── slides/
│       ├── 010-tittel.json
│       ├── 020-executive-summary.json
│       └── ...
├── static/
│   └── uploads/            ← bilder lastet opp via CMS
└── netlify.toml
```

---

## Viktig: slides-index.json

Når du legger til en **ny slide via CMS**, må du oppdatere `_data/slides-index.json` med det nye filnavnet.
Decap CMS oppretter filen automatisk i `_data/slides/`, men `index.html` bruker `slides-index.json` for å vite hvilke filer som finnes.

**Enklest**: Gå til GitHub-repoet → åpne `_data/slides-index.json` → legg til det nye filnavnet i listen → commit.

---

## Endre farger

I **⚙️ Presentasjonsinnstillinger → Global konfig** kan du endre:
- Primærfarge (navy)
- Sekundærfarge (teal)
- Aksentfarge (oransje)
- Lysfarge (krem)

Skriv hex-koder, f.eks. `#0D2B4E`.
